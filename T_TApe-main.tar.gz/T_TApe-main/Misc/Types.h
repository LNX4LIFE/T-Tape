//
// Created by koelion on 04.02.24.
//
#include <linux/input.h>


#ifndef APEX_TYPES_H
#define APEX_TYPES_H

typedef unsigned char byte;
typedef unsigned short int ushort;

#endif //APEX_TYPES_H
